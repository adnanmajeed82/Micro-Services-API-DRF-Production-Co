from django.urls import path
from .views import FeedbackListCreateView, FeedbackRetrieveUpdateDestroyView

urlpatterns = [
    path('feedbacks/', FeedbackListCreateView.as_view(), name='feedback-list'),
    path('feedbacks/<int:pk>/', FeedbackRetrieveUpdateDestroyView.as_view(), name='feedback-detail'),
]
