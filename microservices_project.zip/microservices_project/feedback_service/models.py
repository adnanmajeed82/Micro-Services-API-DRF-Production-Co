from django.db import models

class Feedback(models.Model):
    customer_name = models.CharField(max_length=100)
    content = models.TextField()
    rating = models.PositiveIntegerField()  # Rating on a scale of 1 to 5

    def __str__(self):
        return f"Feedback from {self.customer_name}"
