from django.urls import path
from .views import CallListCreateView, CallRetrieveUpdateDestroyView

urlpatterns = [
    path('calls/', CallListCreateView.as_view(), name='call-list'),
    path('calls/<int:pk>/', CallRetrieveUpdateDestroyView.as_view(), name='call-detail'),
]
