from django.db import models

class Call(models.Model):
    caller = models.CharField(max_length=100)
    receiver = models.CharField(max_length=100)
    duration = models.PositiveIntegerField()  # Call duration in seconds

    def __str__(self):
        return f"Call from {self.caller} to {self.receiver}"
