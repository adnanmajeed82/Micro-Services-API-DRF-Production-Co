from rest_framework import generics
from .models import Call
from .serializers import CallSerializer

class CallListCreateView(generics.ListCreateAPIView):
    queryset = Call.objects.all()
    serializer_class = CallSerializer

class CallRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Call.objects.all()
    serializer_class = CallSerializer
